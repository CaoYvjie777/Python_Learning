# Set this to how many LMs you want to train on diff splits of the data

NUM_FOLDS = 5


# what text to train on (right now it's toronto books)
PRETRAIN_TXT = '/home/mbforbes/repos/ari-holtzman/learning_to_write/data/corpora/tbooks/train.txt'